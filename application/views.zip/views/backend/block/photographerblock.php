<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editphotographer?id=').$before->id; ?>">Creative Artist Details</a></li>
<!--<li><a href="<?php echo site_url('site/viewphotographeralbumgallery?id=').$before->id; ?>">Albums</a></li>-->
<li><a href="<?php echo site_url('site/viewphotographervideo?id=').$before->id; ?>">Creative Artist Videos</a></li>
</ul>
</div>
</section>