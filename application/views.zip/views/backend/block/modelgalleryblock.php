<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editmodelgallery?modelgalleryid=').$before->id."&id=".$before->model; ?>">Gallery Details</a></li>
<li><a href="<?php echo site_url('site/viewmodelgalleryimage?modelgalleryid=').$before->id."&id=".$before->model; ?>">Gallery Images</a></li>
<!--<li><a href="<?php echo site_url('site/viewmodelvideo?id=').$before->id; ?>">Model Videos</a></li>-->
</ul>
</div>
</section>