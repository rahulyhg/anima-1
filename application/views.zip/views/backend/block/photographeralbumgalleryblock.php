<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editphotographeralbumgallery?photographeralbumgalleryid=').$before->id."&id=".$before->photographeralbum; ?>">Gallery Details</a></li>
<li><a href="<?php echo site_url('site/viewphotographeralbumgalleryimage?photographeralbumgalleryid=').$before->id."&id=".$before->photographeralbum; ?>">Album Images</a></li>
<!--<li><a href="<?php echo site_url('site/viewmodelvideo?id=').$before->id; ?>">Model Videos</a></li>-->
</ul>
</div>
</section>